import maestrobatt
import rospy
from std_msgs.msg import Float32
rospy.init_node('batterycheck')

#crée une liste avec les tensions de chaque batterie dans les cases 0 à 7 
# et les courants deux par deux dans les cases 8 à 11
def formArray(battery):
    batList=battery.getState()
    for i in range(8):
        batList[i]=batList[i]/1023*50.5
    for i in range(4):
        batList[i+8]=batList[i+8]/1023*85
    return batlist
    
def publer(pubvolt,pubamp,battery):
    batstate=formArray(battery)
    for i in range(8):
        pubvolt[i].publish(batstate[i])
    for i in range(4)
        pubamp[i].publish(batstate[i+8])

pubvolt = [rospy.Publisher('battery/volt1',Float32 , queue_size=1),rospy.Publisher('battery/volt2',Float32 , queue_size=1),rospy.Publisher('battery/volt3',Float32 , queue_size=1),rospy.Publisher('battery/volt4',Float32 , queue_size=1),rospy.Publisher('battery/volt5',Float32 , queue_size=1),rospy.Publisher('battery/volt6',Float32 , queue_size=1),rospy.Publisher('battery/volt7',Float32 , queue_size=1),rospy.Publisher('battery/volt8',Float32 , queue_size=1)]
pubamp = [rospy.Publisher('battery/amp1',Float32 , queue_size=1),rospy.Publisher('battery/amp2',Float32 , queue_size=1),rospy.Publisher('battery/amp3',Float32 , queue_size=1),rospy.Publisher('battery/amp4',Float32 , queue_size=1)]

battery=maestrobatt.battchecker(2)
rospy.spin()